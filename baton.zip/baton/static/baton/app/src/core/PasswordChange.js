import $ from 'jquery'

const PasswordChange = {
  init: function () {
    $('body').addClass('passwordchange')
  },
}

export default PasswordChange
