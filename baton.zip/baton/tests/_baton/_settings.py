from testwithbaton.api import BatonSetup

BATON_SETUP = BatonSetup.v0_16_4_WITH_IRODS_4_1_9