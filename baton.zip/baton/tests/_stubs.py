from baton.models import IrodsEntity


class StubIrodsEntity(IrodsEntity):
    """
    Stub implement of `IrodsEntity`.
    """
